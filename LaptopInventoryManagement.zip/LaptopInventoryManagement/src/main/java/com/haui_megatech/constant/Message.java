/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.haui_megatech.constant;

/**
 *
 * @author duytran
 */
public class Message {
    
    public static final class User {
        
    }
}
